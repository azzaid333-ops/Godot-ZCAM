extends Node

func _ready() -> void:
	# Cek apakah izin kamera sudah diberikan
	if OS.get_name() == "Android":
			# Ambil daftar izin yang SUDAH disetujui pengguna
		var granted_permissions = OS.get_granted_permissions()
		if not "android.permission.CAMERA" in granted_permissions:
			OS.request_permissions()
			
			
	# Inisialisasi CameraFeed
	_setup_camera()

func _setup_camera() -> void:
	# Tunggu sebentar pastikan izin aktif
	await get_tree().create_timer(0.5).timeout # Gunakan await di Godot 4: await get_tree().create_timer(0.5).timeout
	
	var feeds = CameraServer.feeds()
	if feeds.size() > 0:
		var feed = feeds[0]
		feed.set_active(true)
		$"../TextureRect".texture = feed.get_texture()
	else:
		print("Kamera tidak ditemukan atau izin belum diberikan.")
