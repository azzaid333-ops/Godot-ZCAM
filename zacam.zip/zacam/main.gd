extends Control

@onready var texture_rect: TextureRect = $TextureRect
@onready var native_camera: NativeCamera = $NativeCamera # Pastikan nama node di Scene sesuai

func _ready() -> void:
	# 1. Hubungkan signal dari plugin NativeCamera
	native_camera.camera_permission_granted.connect(_on_permission_granted)
	native_camera.camera_permission_denied.connect(_on_permission_denied)
	native_camera.frame_available.connect(_on_frame_available)
	
	# 2. Cek dan minta izin kamera Android
	if not native_camera.has_camera_permission():
		native_camera.request_camera_permission()
	else:
		_start_camera_feed()

func _on_permission_granted() -> void:
	print("Izin kamera diberikan!")
	_start_camera_feed()

func _on_permission_denied() -> void:
	print("Izin kamera ditolak oleh pengguna.")

func _start_camera_feed() -> void:
	# Bikin konfigurasi feed kamera
	var request = native_camera.create_feed_request()
	# Aktifkan auto upright agar orientasi foto tidak terbalik/miring saat HP diputar
	request.auto_upright = true 
	
	# Jalankan stream kamera
	native_camera.start(request)

func _on_frame_available(frame_info) -> void:
	# Ambil frame asli dan ubah menjadi ImageTexture Godot
	var img: Image = frame_info.get_image()
	if img:
		texture_rect.texture = ImageTexture.create_from_image(img)
